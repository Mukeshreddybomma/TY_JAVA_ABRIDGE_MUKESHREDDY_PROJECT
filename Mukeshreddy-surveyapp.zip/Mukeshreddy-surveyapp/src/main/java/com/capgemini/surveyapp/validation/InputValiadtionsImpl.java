package com.capgemini.surveyapp.validation;

import java.util.ArrayList;

import java.util.regex.Matcher;
import java.util.regex.Pattern;



import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;


import javax.swing.text.DefaultEditorKit.CutAction;

public class InputValiadtionsImpl implements InputValidations {
	Pattern pat = null;
	Matcher mat = null;

	public boolean nameValidation(String name) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean dateValidation(String date) {
		pat = Pattern.compile("[0-9]{4}-(0[1-9]|1[0-2])-(3[0-1]|[1-2][0-9]|0[0-9])");
		mat = pat.matcher(date);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean choiceValidate(String choice) {
		pat = Pattern.compile("[1-9&&[^a-zA-Z]]{1}");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean emailValidation(String email) {
		pat = Pattern.compile("^(.+)@(.+)$");
		mat = pat.matcher(email);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean passwordValidation(String passcode) {
		pat = Pattern.compile("[a-zA-Z0-9@!#$%^&*]+");
		mat = pat.matcher(passcode);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean mobileNoValidation(String phoneNo) {
		pat = Pattern.compile("[6-9][0-9]{9}");
		mat = pat.matcher(phoneNo);
		if (mat.matches()) {
			return true;

		}
		return false;
	}

	public boolean surveyValidation(String survey) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(survey);
		if (mat.matches()) {
			return true;

		}
		return false;
	}

	public boolean descriptionValidation(String description) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(description);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	
	public boolean answerValidation(String answer) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*{1,250}");
		mat = pat.matcher(answer);
		if (mat.matches()) {
			return true;
		}
		return false;
	}


	public boolean multipleanswerValidation(String answer) {
			pat = Pattern.compile("[a-d]{1}");
			mat = pat.matcher(answer);
			if (mat.matches()) {
				return true;
			}
		return false;
	}

	public boolean answerValidation1(String answer) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+?]]*{1,4000}");
		mat = pat.matcher(answer);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean questionValidation(String question) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+?]]*");
		mat = pat.matcher(question);
		if (mat.matches()) {
			return true;
		}
		return false;
	}
}