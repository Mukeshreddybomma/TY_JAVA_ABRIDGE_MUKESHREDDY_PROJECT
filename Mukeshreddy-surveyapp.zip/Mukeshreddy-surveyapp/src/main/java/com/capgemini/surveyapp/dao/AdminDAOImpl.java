package com.capgemini.surveyapp.dao;

import java.util.ArrayList;


import java.util.Iterator;
import java.util.Scanner;
import org.apache.log4j.Logger;

import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.exception.InvalidAdminException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.validation.InputValidations;


public class AdminDAOImpl implements AdminDAO {
	int count = 0;

	static final Logger log = Logger.getLogger(AdminDAOImpl.class);
	InputValidations inputValidations = Factory.getInputValidationInstance();
	public static ArrayList<Adminbean> adminlist = new ArrayList<Adminbean>();
	Scanner sc = new Scanner(System.in);

	public void defaultAdmin() {
		Adminbean adminBean1 = Factory.getAdminbeanInstance();
		adminBean1.setUsername("mukeshbomma");
		adminBean1.setPassword("Bomma@13");
		adminlist.add(adminBean1);
		Adminbean adminBean2 = Factory.getAdminbeanInstance();
		adminBean2.setUsername("mukeshreddy");
		adminBean2.setPassword("Mukesh@13");
		adminlist.add(adminBean2);
	}

	public boolean validateAdmin(String username,String password) {
	
		try {
			Iterator<Adminbean> adminBean3 = adminlist.iterator();
			while (adminBean3.hasNext()) {

				Adminbean admin = adminBean3.next();

				if(username.contentEquals(admin.getUsername()) && password.equals(admin.getPassword())) {
					count++;
				}
			}
			if (count == 0) {
				throw new InvalidAdminException();
			} else {
				log.info("admin found");
				
				AdminService adminService = Factory.getAdminServiceInstance();
				adminService.afterlogin();
				return true;
			}
		} catch (InvalidAdminException e) {
			log.error(e.getMessage());
		}
		return false;
	}

}