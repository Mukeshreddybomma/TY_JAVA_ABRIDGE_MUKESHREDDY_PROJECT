package com.capgemini.surveyapp.validation;

public interface InputValidations {
	
	public boolean nameValidation(String name);

	public boolean dateValidation(String date);

	public boolean choiceValidate(String choice);

	public boolean emailValidation(String email);

	public boolean passwordValidation(String passcode);
	
	public boolean mobileNoValidation(String phoneNo);
	
	public boolean surveyValidation(String survey);
	
	public boolean descriptionValidation(String description);
	
	public boolean questionValidation(String question);
	
	public boolean multipleanswerValidation(String answer);
	
	public boolean answerValidation(String answer);
	
	public boolean answerValidation1(String answer);
	

}

