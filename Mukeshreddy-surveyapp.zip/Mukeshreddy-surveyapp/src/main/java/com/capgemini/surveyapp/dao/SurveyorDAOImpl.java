package com.capgemini.surveyapp.dao;

import java.time.LocalDate;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.exception.InvalidSurveynameException;
import com.capgemini.surveyapp.exception.InvalidSurveyorException;
import com.capgemini.surveyapp.exception.SurveyNotFoundException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;



public class SurveyorDAOImpl implements SurveyorDAO {
	static final Logger log = Logger.getLogger(SurveyorDAOImpl.class);
	InputValidations inputValidations = Factory.getInputValidationInstance();

	Surveyorbean surveyorbean = Factory.getSurveyorbeanInstance();
	static List<Surveyorbean> surveylist = new ArrayList<Surveyorbean>();;
	static List<Surveybean> surveynames = new ArrayList<Surveybean>();

	int count = 0;
	Scanner sc = new Scanner(System.in);

	public void defaultSurveyor() {
		Surveyorbean surveyorbean1 = Factory.getSurveyorbeanInstance();
		surveyorbean1.setUsername("mukeshreddy");
		surveyorbean1.setEmailId("mukesh.bomma@gmail.com");
		surveyorbean1.setPassword("Mukesh@13");
		surveylist.add(surveyorbean1);

		Surveyorbean surveyorbean2 = Factory.getSurveyorbeanInstance();
		surveyorbean2.setUsername("mukeshbomma");
		surveyorbean2.setEmailId("mukesh@gmail.com");
		surveyorbean2.setPassword("Bomma@13");
		surveylist.add(surveyorbean2);
	}
	public boolean validateSurveyor(String username, String password) {
		try {
			int count = 0;

			Iterator<Surveyorbean> surveyor1 = surveylist.iterator();
			while (surveyor1.hasNext()) {
				Surveyorbean surveyor = surveyor1.next();
				if (username.contentEquals(surveyor.getUsername()) && password.equals(surveyor.getPassword())) {
					count++;
				}
			}
			if (count == 0) {
				throw new InvalidSurveyorException();
			} else {
				log.info("suveryor found");
				RegistrationSurveyorService surveyorService = Factory.getSurveyorServiceInstance();
				surveyorService.surveydetails();

			}
		} catch (InvalidSurveyorException e) {
			log.error(e.getMessage());
		}
		return false; 
	}

	public void defaultSurvey() {
		Surveybean surveybean1 = Factory.getSurveybeanInstance();

		surveybean1.setSurveyname("india");
		surveybean1.setDescription("place");
		surveybean1.setStartdate(LocalDate.of(2015, 11, 16));
		surveybean1.setEnddate(LocalDate.of(2018, 11, 16));
		surveybean1.setQ1("what is your favourite place in india?");
		surveybean1.setQ2("what is your favourite food in india?");
		surveybean1.setQ3("describe favourite place?");
		surveybean1.setQ4("describe about india?");
		surveybean1.setQ5("which place you like");
		surveybean1.setOption1("hyderabad");
		surveybean1.setOption2("mumbai");
		surveybean1.setOption3("kerala");
		surveybean1.setOption4("goa");
		surveybean1.setQ6("better place to eat");
		surveybean1.setOpt1("hyderabad");
		surveybean1.setOpt2("mumbai");
		surveybean1.setOpt3("kerala");
		surveybean1.setOpt4("goa");
		surveybean1.setDistribute("mukeshbomma");
		surveynames.add(surveybean1);

		Surveybean surveybean2 = Factory.getSurveybeanInstance();
		surveybean2.setSurveyname("amazon");
		surveybean2.setDescription("app");
		surveybean2.setStartdate(LocalDate.of(2015, 11, 16));
		surveybean2.setEnddate(LocalDate.of(2018, 11, 16));
		surveybean2.setQ1("describe about amazon ?");
		surveybean2.setQ2("product which u like in amazon?");
		surveybean2.setQ3("describe about amazon?");
		surveybean2.setQ4("product which u like in amazon?");
		surveybean2.setQ5("rating for app");
		surveybean2.setOption1("good");
		surveybean2.setOption2("bad");
		surveybean2.setOption3("excellent");
		surveybean2.setOption4("avg");
		surveybean2.setQ6("services provided by amazon");
		surveybean2.setOpt1("good");
		surveybean2.setOpt2("excellent");
		surveybean2.setOpt3("avg");
		surveybean2.setOpt4("bad");
		surveybean2.setDistribute("mukeshreddy");
		surveynames.add(surveybean2);

	}

	

	public boolean createSurvey(Surveyorbean surveyor) {
		InputValidations inputValidations = Factory.getInputValidationInstance();
		RegistrationSurveyorService registrationSurveyorService = Factory.getSurveyorServiceInstance();
		SurveyorDAO surveryorDao = Factory.getSurveyorDAOInstance();
		AdminDAO adminDao = Factory.getAdminDAOInstance();
		RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
		Surveybean surveybean = Factory.getSurveybeanInstance();
		Surveybean options = Factory.getSurveybeanInstance();
		log.info("enter survey name (a-z)");
		String survey = sc.next();
		while (!inputValidations.surveyValidation(survey)) {
			log.info("please enter valid surveyname");
			survey = sc.next();
		}

		log.info("enter survey description (a-z)");
		String description = sc.next();
		while (!inputValidations.surveyValidation(description)) {
			log.info("please enter valid description");
			description = sc.next();
		}
		log.info("enter start date (YYYY-MM-DD)");
		String startdate = sc.next();
		while (!inputValidations.dateValidation(startdate)) {
			log.info("please enter valid startdate");
			startdate = sc.next();
		}
		LocalDate sd = LocalDate.parse(startdate);

		log.info("enter end date (YYYY-MM-DD)");
		String enddate = sc.next();
		while (!inputValidations.dateValidation(enddate)) {
			log.info("please enter valid enddate");
			enddate = sc.next();
		}
		LocalDate ed = LocalDate.parse(enddate);
		sc.nextLine();
		log.info("enter question1 with one line answer ");
		String q1 = sc.nextLine();
		while (!inputValidations.questionValidation(q1)) {
			log.info("please enter valid question");
			q1 = sc.nextLine();
		}

		log.info("enter question2 with one line answer");

		String q2 = sc.nextLine();
		while (!inputValidations.questionValidation(q2)) {
			log.info("please enter valid question");
			q2 = sc.nextLine();
		}

		log.info("enter question3 with discriptive answer");

		String q3 = sc.nextLine();
		while (!inputValidations.questionValidation(q3)) {
			log.info("please enter valid question");
			q3 = sc.nextLine();
		}

		log.info("enter question4 with discriptive answer");

		String q4 = sc.nextLine();
		while (!inputValidations.questionValidation(q4)) {
			log.info("please enter valid question");
			q4 = sc.nextLine();
		}
		log.info("enter question5 with multiple choice with one or more answer");

		String q5 = sc.nextLine();
		while (!inputValidations.questionValidation(q5)) {
			log.info("please enter valid question");
			q5 = sc.nextLine();
		}

		log.info("a.option ");

		String option1 = sc.nextLine();
		surveybean.setOption1(option1);

		log.info("b.option ");
		String option2 = sc.nextLine();
		surveybean.setOption2(option2);

		log.info("c.option ");
		String option3 = sc.nextLine();
		surveybean.setOption3(option3);

		log.info("d.option ");
		String option4 = sc.nextLine();
		surveybean.setOption4(option4);

		log.info("enter question5 with multiple choice with  answer");

		String q6 = sc.nextLine();
		while (!inputValidations.questionValidation(q6)) {
			log.info("please enter valid question");
			q6 = sc.nextLine();
		}

		log.info("a.option ");

		String opt1 = sc.nextLine();
		surveybean.setOpt1(opt1);

		log.info("b.option ");
		String opt2 = sc.nextLine();
		surveybean.setOpt2(opt2);

		log.info("c.option ");
		String opt3 = sc.nextLine();
		surveybean.setOpt3(opt3);

		log.info("d.option ");
		String opt4 = sc.nextLine();
		surveybean.setOpt4(opt4);
		
		log.info("enter respondent name to distribute");
		String distribute =sc.next();
		while (!inputValidations.nameValidation(distribute)) {
			log.info("please enter valid username");
		}
		surveybean.setSurveyname(survey);
		surveybean.setDescription(description);
		surveybean.setStartdate(sd);
		surveybean.setEnddate(ed);
		surveybean.setQ1(q1);
		surveybean.setQ2(q2);
		surveybean.setQ3(q3);
		surveybean.setQ4(q4);
		surveybean.setQ5(q5);
		surveybean.setQ6(q6);
		surveybean.setDistribute(distribute);

		ArrayList<Surveybean> List = new ArrayList<Surveybean>();
		List.add(surveybean);
		surveynames.addAll(List);
		if (List.isEmpty()) {
			log.info("survey  not added");

		} else {
			log.info("survey is added");
			return true;
		}
		return false;
	}

	public boolean editSurvey(Surveyorbean surveyor) {
		InputValidations inputValidations = Factory.getInputValidationInstance();
		RegistrationSurveyorService registrationSurveyorService = Factory.getSurveyorServiceInstance();
		SurveyorDAO surveryorDao = Factory.getSurveyorDAOInstance();
		RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
		log.info("enter survey name");
		String survey1 = sc.next();
		while (!inputValidations.surveyValidation(survey1)) {
			log.info("please enter valid surveyname");
			survey1 = sc.next();
		}
		for (Surveybean surveybean : surveynames) {
			if (surveybean.getSurveyname().contentEquals(survey1)) {
				count++;
				log.info("updating");

				log.info("enter  new survey name");
				String survey = sc.next();
				while (!inputValidations.surveyValidation(survey)) {
					log.info("please enter valid surveyname");
					survey = sc.next();
				}
				log.info("enter new survey description");
				String description = sc.next();
				while (!inputValidations.surveyValidation(description)) {
					log.info("please enter valid description");
					description = sc.next();
				}
				log.info("enter  new start date");
				String startdate = sc.next();
				while (!inputValidations.dateValidation(startdate)) {
					log.info("please enter valid startdate");
					startdate = sc.next();
				}
				LocalDate sd = LocalDate.parse(startdate);

				log.info("enter new end date");
				String enddate = sc.next();
				while (!inputValidations.dateValidation(enddate)) {
					log.info("please enter valid enddate");
					enddate = sc.next();
				}
				LocalDate ed = LocalDate.parse(enddate);

				log.info("enter new question1 with one line answer ");
				String q1 = sc.nextLine();
				while (!inputValidations.questionValidation(q1)) {

					q1 = sc.nextLine();
				}

				log.info("enter new question2 with one line answer");

				String q2 = sc.nextLine();
				while (!inputValidations.questionValidation(q2)) {
					log.info("please enter valid question");
					q2 = sc.nextLine();
				}

				log.info("enter new question3 with discriptive answer");

				String q3 = sc.nextLine();
				while (!inputValidations.questionValidation(q3)) {
					log.info("please enter valid question");
					q3 = sc.nextLine();
				}

				log.info("enter new question4 with discriptive answer");

				String q4 = sc.nextLine();
				while (!inputValidations.questionValidation(q4)) {
					log.info("please enter valid question");
					q4 = sc.nextLine();
				}
				log.info("enter respondent name to distribute");
				String distribute =sc.next();
				while (!inputValidations.nameValidation(distribute)) {
					log.info("please enter valid username");
				}

				surveybean.setSurveyname(survey);
				surveybean.setDescription(description);
				surveybean.setStartdate(sd);
				surveybean.setEnddate(ed);
				surveybean.setQ1(q1);
				surveybean.setQ2(q2);
				surveybean.setQ3(q3);
				surveybean.setQ4(q4);
				surveybean.setDescription(distribute);
			}
		}

		try {
			if (count == 0) {
				throw new SurveyNotFoundException();
			}else {
				log.info("survey updated");
				return true;
			}
		} catch (SurveyNotFoundException e) {
			log.error(e.getMessage());
		}
		return false;
	}

	public boolean deleteSurvey(String surveyTitle) {
		InputValidations inputValidations = Factory.getInputValidationInstance();

		log.info("enter survey name");
		String survey = sc.next();
		while (!inputValidations.surveyValidation(survey)) {
			log.info("please enter valid surveyname");
			survey = sc.next();
		}
		Iterator<Surveybean> surveybean = surveynames.iterator();
		while (surveybean.hasNext()) {

			Surveybean survey1 = surveybean.next();

			if (survey1.getSurveyname().contentEquals(survey)) {
				count++;
				surveybean.remove();
			}
		}
		try {
			if (count == 0) {
				throw new SurveyNotFoundException();
			} else {
				log.info("suvery deleted");
				return true;
			}
		} catch (SurveyNotFoundException e) {
			log.error(e.getMessage());
		}

		return false;
	}

	public List<Surveybean> getAllSurveys() {
		log.info("list of survey");
		for (Surveybean surveybean : surveynames) {
			if (surveynames.isEmpty()) {
				log.info("there is no surveylist");
			} else {
				log.info(surveybean);
			}
		}
		return surveynames;
	}
	
}
