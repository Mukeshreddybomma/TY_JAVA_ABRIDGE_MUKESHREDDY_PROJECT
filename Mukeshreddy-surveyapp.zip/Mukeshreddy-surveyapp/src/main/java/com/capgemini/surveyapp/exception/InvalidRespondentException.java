package com.capgemini.surveyapp.exception;

public class InvalidRespondentException extends RuntimeException{
	String message="Respondent  not found";
public InvalidRespondentException() {
		
	}
	public InvalidRespondentException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}

}
