package com.capgemini.surveyapp.factory;

import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;

public class Factory {
	
 public static Surveyorbean getSurveyorbeanInstance() {
	Surveyorbean surveyorbean=new Surveyorbean();
	return surveyorbean;
 }
 public static SurveyorDAO getSurveyorDAOInstance(){
	 SurveyorDAO surveyorDao = new SurveyorDAOImpl();
	 return surveyorDao;
	 
 }
 public static  RegistrationSurveyorService getSurveyorServiceInstance() {
	 RegistrationSurveyorService surveyorService = new RegistrationSurveyorService();
	 return surveyorService;
 }
 public static Adminbean getAdminbeanInstance() {
	 Adminbean adminBean = new  Adminbean();
	 return adminBean;
	 
 }
 public static AdminDAO getAdminDAOInstance() {
	 AdminDAO adminDao = new AdminDAOImpl();
	 return adminDao;
 }
 public static  AdminService  getAdminServiceInstance() {
	 AdminService adminService =new AdminService();
	 return adminService;
 }
 public static Respondentbean  getRespondentbeanInstance() {
	 Respondentbean respondentbean = new Respondentbean();
	 return respondentbean;
 }
 public static RespondentDAO getRespondentDAOInstance() {
	RespondentDAO respondentDao=new RespondentDAOImpl();
	return respondentDao; 
 }
 public static RespondentService getRespondentServiceInstance() {
	 RespondentService respondentService = new RespondentService();
	 return respondentService;
 }
 
 public static Surveybean getSurveybeanInstance() {
	 Surveybean surveybean = new Surveybean();
	 return surveybean;
 }

 public static Resultbean getResultbeanInstance() {
	 Resultbean resultbean =new Resultbean();
	return resultbean;
	 
 }
 
 public static InputValidations getInputValidationInstance() {
	 return new InputValiadtionsImpl();
 }

 
 
}
