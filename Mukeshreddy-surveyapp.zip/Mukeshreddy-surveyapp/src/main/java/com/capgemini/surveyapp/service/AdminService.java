package com.capgemini.surveyapp.service;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.controller.SurveyController;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.exception.CheckException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;



public class AdminService {
	Scanner sc = new Scanner(System.in);
	static Logger log = Logger.getLogger(RegistrationSurveyorService.class);
	Adminbean adminbean= Factory.getAdminbeanInstance();
	
	
	public boolean adminService() {
		AdminDAO adminDao=Factory.getAdminDAOInstance();
		adminDao.validateAdmin("mukeshreddy", "Mukesh@13");
		return true;
	}
	public  boolean afterlogin() {
		InputValidations inputValidation=Factory.getInputValidationInstance();
		Properties props= new Properties();
		try {
			props.load(new FileInputStream("db.properties"));
		}catch(IOException e) {
			e.printStackTrace();
		}
		do {
		log.info("Enter your Choice ");
		log.info(" 1.Login as Surveyor ");
		log.info("2.Login as Respondent ");
		String choice=sc.nextLine();
		while(!inputValidation.choiceValidate(choice)) {
			System.out.println("Please enter Valid Choice");
			choice=sc.next();
		}
			int choice1=Integer.parseInt(choice);
			switch(choice1) {
			
			case 1:
				String SurveyorUsername =props.getProperty("surveyorUsername");
				String SurveyorPassword =props.getProperty("surveyorPassword");
				SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
				if(surveyorDao.validateSurveyor(SurveyorUsername,SurveyorPassword)) {
					RegistrationSurveyorService.surveydetails();
				}else {
					log.info("Login failed.\n");
					afterlogin();
				}
				break;
			case 2:
				RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
				respondentDao.respondentlogin();
				break;
			case 3:
				log.info("Thank you...");
				SurveyController.main(null);
				default:
					log.info(" select valid choice");
					break;
			}
		} while(true);
		
	}
}
