package com.capgemini.surveyapp.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;

import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValidations;


public class SurveyController {
	static final Logger log = Logger.getLogger(SurveyController.class);

	public static void main(String[] args) {
		InputValidations inputValidations = Factory.getInputValidationInstance();
		SurveyorDAO surveryorDao = Factory.getSurveyorDAOInstance();
		Adminbean adminbean= Factory.getAdminbeanInstance();
		RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
		Surveyorbean surveyorbean=Factory.getSurveyorbeanInstance();
		AdminDAO adminDao = Factory.getAdminDAOInstance();
		surveryorDao.defaultSurveyor();
		surveryorDao.defaultSurvey();
		respondentDao.defaultrespondent();
		adminDao.defaultAdmin();
		Properties props= new Properties();
		try {
			props.load(new FileInputStream("db.properties"));
		}catch(IOException e) {
			e.printStackTrace();
		}
		log.info("welcome to survey management");
		
		do {
			log.info("please tell who are you");
			log.info("1.Admin login");
			log.info("2.Surveyor login");
			log.info("3.Respondent login");
			log.info("4. Exit");
			Scanner sc = new Scanner(System.in);
			log.info("select a choice (1-4))");
			String choice = sc.next();
			while (!inputValidations.choiceValidate(choice)) {
				System.out.println("please enter valid choice");
				choice = sc.next();
			}
			int choice1 = Integer.parseInt(choice);

			switch (choice1) {

			case 1:
				String AdminUsername =props.getProperty("adminUsername");
				String AdminPassword =props.getProperty("adminPassword");
				AdminDAO adminDao1 = Factory.getAdminDAOInstance();
				if(adminDao1.validateAdmin(AdminUsername,AdminPassword)) {
					AdminService adminService=Factory.getAdminServiceInstance();
					adminService.afterlogin();
				}else {
					log.info("Login failed\n");
					SurveyController.main(null);
				} 
				break;
			case 2:
				String SurveyorUsername =props.getProperty("surveyorUsername");
				String SurveyorPassword =props.getProperty("surveyorPassword");
				SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
				if(surveyorDao.validateSurveyor(SurveyorUsername,SurveyorPassword)) {
					RegistrationSurveyorService surveyorService = Factory.getSurveyorServiceInstance();
					surveyorService.surveydetails();
				}else {
					log.info("Login failed.\n");
					SurveyController.main(null);
				}
				break;
			
			case 3:
				RespondentDAO respondentDAO = Factory.getRespondentDAOInstance();
				respondentDAO.respondentlogin();
				break;
			case 4:
				log.info("Exit!!");
				
				break;
			default:
				log.info("Select correct choice");
				break;
				}
		}while(true);
		
	}
}
