package com.capgemini.surveyapp.exception;

public class InvalidAdminException extends RuntimeException{
	String message="Admin  not found";
public InvalidAdminException() {
		
	}
	public InvalidAdminException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}

}
