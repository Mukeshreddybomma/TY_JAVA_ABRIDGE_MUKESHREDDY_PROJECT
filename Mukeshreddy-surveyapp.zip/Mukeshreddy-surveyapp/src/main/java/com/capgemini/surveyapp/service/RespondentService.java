package com.capgemini.surveyapp.service;

import java.util.Scanner;



import org.apache.log4j.Logger;


import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;



public class RespondentService {
	Scanner sc = new Scanner(System.in);
	static Logger log = Logger.getLogger(RespondentService.class);

	public boolean respondentService() {
		RespondentDAO respondentDao = Factory.getRespondentDAOInstance();
		respondentDao.respondentlogin();
		return true;
	}

	public boolean respondentlist() {
		InputValidations inputValidation = Factory.getInputValidationInstance();
		log.info("Logged in successfully\n");
		do {
			log.info(" Enter the required options ");
			log.info(" 1. Respond for list ");
			log.info(" 2. View lists ");
			String choice = sc.next();
			while (!inputValidation.choiceValidate(choice)) {
				System.out.println("please enter valid choice");
				choice = sc.next();
			}
			int choice1 = Integer.parseInt(choice);
			switch (choice1) {
			case 1:
				RespondentDAO respondentDao2=Factory.getRespondentDAOInstance();
				respondentDao2.viewrespondlist();
				break;
			case 2:
				AdminService adminService = Factory.getAdminServiceInstance();
				adminService.afterlogin();
				break;


			}
		} while (true);
	}}
