package com.capgemini.surveyapp.dao;

import com.capgemini.surveyapp.bean.Adminbean;

public interface AdminDAO {
 
	
	public boolean validateAdmin(String username, String password);

	public void defaultAdmin();




	
}
