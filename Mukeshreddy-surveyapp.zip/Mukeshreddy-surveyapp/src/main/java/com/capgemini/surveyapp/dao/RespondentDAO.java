package com.capgemini.surveyapp.dao;

import java.util.List;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;



public interface RespondentDAO {
	
	public void defaultrespondent();
	public List<Resultbean> viewrespondlist();
	public List<Respondentbean> responseSurvey(String distribute);
	public boolean respondentlogin();
}
