package com.capgemini.surveyapp.dao;

import java.util.List;

import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;

public interface SurveyorDAO {
	public void defaultSurveyor();

	public boolean validateSurveyor(String username, String password);

	public boolean createSurvey(Surveyorbean surveyor);

	public boolean editSurvey(Surveyorbean surveyor);

	public boolean deleteSurvey(String surveyTitle);

	public List<Surveybean> getAllSurveys();

	public void defaultSurvey();


}
