package com.capgemini.surveyapp.service;

import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

public class RegistrationSurveyorService {
	static Logger log = Logger.getLogger(RegistrationSurveyorService.class);

	public boolean surveyorService() {
		SurveyorDAO surveyorDao = Factory.getSurveyorDAOInstance();
		surveyorDao.validateSurveyor("mukeshreddy", "Mukesh@13");
		return true;
	}

	public static boolean surveydetails() {
		InputValidations inputValidation = Factory.getInputValidationInstance();
		Surveyorbean surveyor = Factory.getSurveyorbeanInstance();
		log.info("1.create survey");
		log.info("2.edit survey");
		log.info("3.delete survey");
		log.info("4 .List all surveys");
		log.info("5.Back");
		Scanner sc = new Scanner(System.in);
		String choice = sc.next();
		while (!inputValidation.choiceValidate(choice)) {
			System.out.println("please enter valid choice");
			choice = sc.nextLine();
		}
		int choice1 = Integer.parseInt(choice);

		switch (choice1) {

		case 1:
			SurveyorDAO surveyorDao1 = Factory.getSurveyorDAOInstance();
			surveyorDao1.createSurvey(surveyor);
			RegistrationSurveyorService.surveydetails();
			break;
		case 2:
			SurveyorDAO surveyorDao2 = Factory.getSurveyorDAOInstance();
			surveyorDao2.editSurvey(surveyor);
			RegistrationSurveyorService.surveydetails();
			break;

		case 3:
			SurveyorDAO surveyorDao3 = Factory.getSurveyorDAOInstance();
			surveyorDao3.deleteSurvey("surveyTitle");
			RegistrationSurveyorService.surveydetails();
			break;
		case 4:
			SurveyorDAO surveyorDao4 = Factory.getSurveyorDAOInstance();
			surveyorDao4.getAllSurveys();
			RegistrationSurveyorService.surveydetails();
			break;

		case 5:
			AdminService adminService = Factory.getAdminServiceInstance();
			adminService.afterlogin();

			break;
		}
		while (true)
			;
	}

}
