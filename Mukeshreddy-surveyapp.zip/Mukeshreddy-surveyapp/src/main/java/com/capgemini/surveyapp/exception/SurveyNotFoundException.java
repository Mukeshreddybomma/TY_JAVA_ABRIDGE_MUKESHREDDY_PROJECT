package com.capgemini.surveyapp.exception;

public class SurveyNotFoundException extends RuntimeException{
	String message="Survery  not found";
public SurveyNotFoundException() {
		
	}
	public SurveyNotFoundException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}


}
