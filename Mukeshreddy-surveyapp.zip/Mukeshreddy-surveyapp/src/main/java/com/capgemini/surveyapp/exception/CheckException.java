package com.capgemini.surveyapp.exception;

public class CheckException extends RuntimeException {
	String message = "Please Enter a Valid Choice";

	public CheckException() {
		
	}

	public CheckException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;
		
	}
}
