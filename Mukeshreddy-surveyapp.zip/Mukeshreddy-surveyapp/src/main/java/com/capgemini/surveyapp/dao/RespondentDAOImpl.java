package com.capgemini.surveyapp.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.naming.spi.DirStateFactory.Result;
import org.apache.log4j.Logger;

import com.capgemini.surveyapp.bean.Adminbean;
import com.capgemini.surveyapp.bean.Respondentbean;
import com.capgemini.surveyapp.bean.Resultbean;
import com.capgemini.surveyapp.bean.Surveybean;
import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.dao.AdminDAO;
import com.capgemini.surveyapp.dao.AdminDAOImpl;
import com.capgemini.surveyapp.dao.RespondentDAO;
import com.capgemini.surveyapp.dao.RespondentDAOImpl;
import com.capgemini.surveyapp.dao.SurveyorDAO;
import com.capgemini.surveyapp.dao.SurveyorDAOImpl;
import com.capgemini.surveyapp.exception.InvalidRespondentException;
import com.capgemini.surveyapp.exception.InvalidSurveynameException;
import com.capgemini.surveyapp.exception.SurveyNotFoundException;
import com.capgemini.surveyapp.factory.Factory;
import com.capgemini.surveyapp.service.AdminService;
import com.capgemini.surveyapp.service.RegistrationSurveyorService;
import com.capgemini.surveyapp.service.RespondentService;
import com.capgemini.surveyapp.validation.InputValiadtionsImpl;
import com.capgemini.surveyapp.validation.InputValidations;

public class RespondentDAOImpl implements RespondentDAO {
	static final Logger log = Logger.getLogger(RespondentDAOImpl.class);

	InputValidations inputValidations = Factory.getInputValidationInstance();

	public static ArrayList<Respondentbean> respondentlist = new ArrayList<Respondentbean>();

	Resultbean resultbean = Factory.getResultbeanInstance();

	public static ArrayList<Resultbean> respondentsurvey = new ArrayList<Resultbean>();

	Surveybean surveybean = Factory.getSurveybeanInstance();

	Scanner sc = new Scanner(System.in);

	int count = 0;
	int count1 = 0;

	public void defaultrespondent() {
		Respondentbean respondentbean1 = Factory.getRespondentbeanInstance();
		respondentbean1.setUsername("mukeshreddy");
		respondentbean1.setPassword("Mukesh@13");
		respondentbean1.setPhoneNo("8096741045");
		respondentlist.add(respondentbean1);
		Respondentbean respondentbean2 = Factory.getRespondentbeanInstance();
		respondentbean2.setUsername("mukeshbomma");
		respondentbean2.setPassword("Mukesh@13");
		respondentbean2.setPhoneNo("8096741045");
		respondentlist.add(respondentbean2);
		Respondentbean respondentbean3 = Factory.getRespondentbeanInstance();
		respondentbean3.setUsername("mukesh");
		respondentbean3.setPassword("Mukesh@13");
		respondentbean3.setPhoneNo("8096741045");
		respondentlist.add(respondentbean3);
		Respondentbean respondentbean4 = Factory.getRespondentbeanInstance();
		respondentbean4.setUsername("bomma");
		respondentbean4.setPassword("Mukesh@13");
		respondentbean4.setPhoneNo("8096741045");
		respondentlist.add(respondentbean4);
		Respondentbean respondentbean5 = Factory.getRespondentbeanInstance();
		respondentbean5.setUsername("capgemini");
		respondentbean5.setPassword("Mukesh@13");
		respondentbean5.setPhoneNo("8096741045");
		respondentlist.add(respondentbean5);
		Respondentbean respondentbean6 = Factory.getRespondentbeanInstance();
		respondentbean6.setUsername("reddy");
		respondentbean6.setPassword("Mukesh@13");
		respondentbean6.setPhoneNo("8096741045");
		respondentlist.add(respondentbean6);

	}

	public List<Respondentbean> responseSurvey(String distribute) {
		log.info("list of respondents");
		for (Respondentbean respondentbean : respondentlist) {
			log.info("respondentnames=" + respondentbean.getUsername());
		}
		log.info("enter name of respondent to distribute");
		String respondentnames = sc.next();

		for (Respondentbean respondentname : respondentlist) {
			if (respondentname.getUsername().contentEquals(respondentnames)) {
				count++;
			}
			try {
				if (count == 0) {
					throw new InvalidSurveynameException();
				} else {
					log.info("survey distributed to=" + respondentnames);
					respondentname.setUsername(respondentnames);

					for (Surveybean surveybean : SurveyorDAOImpl.surveynames) {
						surveybean.setDistribute(respondentnames);

						RespondentDAO daorespondent = Factory.getRespondentDAOInstance();
						daorespondent.respondentlogin();
					}

				}
			} catch (InvalidSurveynameException e) {
				log.error(e.getMessage());
			}
		}
		return respondentlist;
	}

	public boolean respondentlogin() {
		Respondentbean respondentbean = Factory.getRespondentbeanInstance();
		log.info("enter respondent username(a-z)");
		String username = sc.next();
		while (!inputValidations.nameValidation(username)) {
			log.info("please enter valid username");
			username = sc.next();
		}
		log.info("enter your contact number(starts with 6-9,10 digids) ");
		String phoneNo = sc.next();
		while (!inputValidations.mobileNoValidation(phoneNo)) {
			log.info("please enter valid  contact number");
			phoneNo = sc.next();
		}
		Long phonenum = Long.parseLong(phoneNo);

		log.info("enter your password (a to z A to Z 0 to 9 @!#$%)");
		String passcode = sc.next();
		while (!inputValidations.passwordValidation(passcode)) {
			log.info("please enter valid password");
			passcode = sc.next();
		}
		try {
			Iterator<Respondentbean> respondentBean3 = respondentlist.iterator();
			while (respondentBean3.hasNext()) {
				Respondentbean repondent = respondentBean3.next();
				if (repondent.getUsername().contentEquals(username)
						&& repondent.getPassword().contentEquals(passcode)) {
					count++;
				}
			}
			if (count == 0) {
				throw new InvalidRespondentException();
			} else {
				log.info("respondent found");
				for (Respondentbean respondentbean3 : respondentlist) {
					if (respondentbean3.getUsername().contentEquals(username)) {
						for (Surveybean surveybean : SurveyorDAOImpl.surveynames) {
							if (surveybean.getDistribute().contentEquals(username)) {
								count1++;
								log.info("surveyname=" + surveybean.getSurveyname());

								log.info(surveybean.getQ1());

								log.info(" enter answer for question1 (a-zA-Z(250))");
								sc.nextLine();
								String answer1 = sc.nextLine();
								while (!inputValidations.answerValidation(answer1)) {
									log.info("please enter valid answer");
									answer1 = sc.nextLine();
								}
								resultbean.setAnswer1(answer1);
								log.info(surveybean.getQ2());

								log.info(" enter answer for question 2(a-zA-Z(250))");

								String answer2 = sc.nextLine();
								while (!inputValidations.answerValidation(answer2)) {
									log.info("please enter valid answer");
									answer2 = sc.nextLine();
								}
								resultbean.setAnswer2(answer2);
								log.info(surveybean.getQ3());

								log.info(" enter answer for question 3(a-zA-Z(4000))");
								String answer3 = sc.nextLine();
								while (!inputValidations.answerValidation1(answer3)) {
									log.info("please enter valid answer");
									answer3 = sc.nextLine();
								}
								resultbean.setAnswer3(answer3);

								log.info(" enter answer for question 4(a-zA-Z(4000))");
								String answer4 = sc.nextLine();
								while (!inputValidations.answerValidation1(answer4)) {
									log.info("please enter valid answer");
									answer4 = sc.nextLine();
								}
								resultbean.setAnswer4(answer4);
								log.info(surveybean.getQ5());

								log.info("select option");
								log.info("a." + surveybean.getOption1());
								log.info("b." + surveybean.getOption2());
								log.info("c." + surveybean.getOption3());
								log.info("d." + surveybean.getOption4());

								log.info("enter answer for question5 (a-d)");
								String answer5 = sc.next();

								while (!inputValidations.multipleanswerValidation(answer5)) {
									log.info("please enter valid answer");
									answer5 = sc.next();
								}
								resultbean.setAnswer5(answer5);

								log.info(surveybean.getQ6());

								log.info("select option");
								log.info("a." + surveybean.getOpt1());
								log.info("b." + surveybean.getOpt2());
								log.info("c." + surveybean.getOpt3());
								log.info("d." + surveybean.getOpt4());

								log.info("enter answer fot question6(a-d)");
								String answer6 = sc.next();
								while (!inputValidations.multipleanswerValidation(answer6)) {
									log.info("please enter valid answer");
									answer6 = sc.next();
								}
								resultbean.setAnswer6(answer6);
								ArrayList<Resultbean> List = new ArrayList<Resultbean>();
								List.add(resultbean);
								respondentsurvey.addAll(List);
								log.info("thanks for response\n");
								do {
								log.info("select a option(1-2)");
								log.info("1.view response");
								log.info("2.back");

								String choice = sc.next();
								while (!inputValidations.choiceValidate(choice)) {
									System.out.println("please enter valid choice");
									choice = sc.next();
								}
								int choice1 = Integer.parseInt(choice);

								switch (choice1) {
								case 1:
									RespondentDAO respondentDao2 = Factory.getRespondentDAOInstance();
									respondentDao2.viewrespondlist();
									break;

								case 2:
									AdminService adminService = Factory.getAdminServiceInstance();
									adminService.afterlogin();
									break;
								default:
									log.info("Select correct choice");
									break;
								}

							}while(true);
						}
						try {
							if (count1 == 0) {
								throw new SurveyNotFoundException();
							}
						} catch (SurveyNotFoundException e) {
							log.error(e.getMessage());
						}

					}

				}
			}
		}} catch (InvalidRespondentException e) {
			log.error(e.getMessage());
		}
		return false;
	}

	public List<Resultbean> viewrespondlist() {
		log.info("respondes for survey");
		for (Resultbean resultbean : respondentsurvey) {
			if (respondentsurvey.isEmpty()) {
				log.info("there is no response");
			} else {
				System.out.println(resultbean);
			}

		}

		return respondentsurvey;

	}

}
