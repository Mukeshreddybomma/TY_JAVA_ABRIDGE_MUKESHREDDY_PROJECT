package com.capgemini.surveyapp.exception;

public class InvalidSurveyorException extends RuntimeException{
	String message="Surveryor  not found";
public InvalidSurveyorException() {
		
	}
	public InvalidSurveyorException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}

}
