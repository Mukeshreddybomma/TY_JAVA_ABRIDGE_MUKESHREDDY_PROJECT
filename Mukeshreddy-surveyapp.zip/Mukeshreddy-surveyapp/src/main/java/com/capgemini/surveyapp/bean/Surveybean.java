package com.capgemini.surveyapp.bean;

import java.time.LocalDate;
import java.util.Arrays;

public class Surveybean {
 private String surveyname;
 private String description;
 private LocalDate startdate;
 private LocalDate enddate;
 private String q1,q2,q3,q4,q5,q6,option1,option2,option3,option4, opt1,opt2,opt3,opt4;
 private String distribute;
 
public String getDistribute() {
	return distribute;
}
public void setDistribute(String distribute) {
	this.distribute = distribute;
}
public String getSurveyname() {
	return surveyname;
}
public String getOpt1() {
	return opt1;
}
public void setOpt1(String opt1) {
	this.opt1 = opt1;
}
public String getOpt2() {
	return opt2;
}
public void setOpt2(String opt2) {
	this.opt2 = opt2;
}
public String getOpt3() {
	return opt3;
}
public void setOpt3(String opt3) {
	this.opt3 = opt3;
}
public String getOpt4() {
	return opt4;
}
public void setOpt4(String opt4) {
	this.opt4 = opt4;
}
public void setSurveyname(String surveyname) {
	this.surveyname = surveyname;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public LocalDate getStartdate() {
	return startdate;
}
public void setStartdate(LocalDate startdate) {
	this.startdate = startdate;
}
public LocalDate getEnddate() {
	return enddate;
}
public void setEnddate(LocalDate enddate) {
	this.enddate = enddate;
}
public String getQ1() {
	return q1;
}
public void setQ1(String q1) {
	this.q1 = q1;
}
public String getQ2() {
	return q2;
}
public void setQ2(String q2) {
	this.q2 = q2;
}
public String getQ3() {
	return q3;
}
public void setQ3(String q3) {
	this.q3 = q3;
}
public String getQ4() {
	return q4;
}
public void setQ4(String q4) {
	this.q4 = q4;
}
public String getQ5() {
	return q5;
}
public void setQ5(String q5) {
	this.q5 = q5;
}
public String getQ6() {
	return q6;
}
public void setQ6(String q6) {
	this.q6 = q6;
}
public String getOption1() {
	return option1;
}
public void setOption1(String option1) {
	this.option1 = option1;
}
public String getOption2() {
	return option2;
}
public void setOption2(String option2) {
	this.option2 = option2;
}
public String getOption3() {
	return option3;
}
public void setOption3(String option3) {
	this.option3 = option3;
}
public String getOption4() {
	return option4;
}
public void setOption4(String option4) {
	this.option4 = option4;
}
@Override
public String toString() {
	return "Surveybean [surveyname=" + surveyname + ", description=" + description + ", startdate=" + startdate
			+ ", enddate=" + enddate + ", q1=" + q1 + ", q2=" + q2 + ", q3=" + q3 + ", q4=" + q4 + ", q5=" + q5
			+ ", q6=" + q6 + ", option1=" + option1 + ", option2=" + option2 + ", option3=" + option3 + ", option4="
			+ option4 + ", opt1=" + opt1 + ", opt2=" + opt2 + ", opt3=" + opt3 + ", opt4=" + opt4 + ", distribute="
			+ distribute + "]";
}


}