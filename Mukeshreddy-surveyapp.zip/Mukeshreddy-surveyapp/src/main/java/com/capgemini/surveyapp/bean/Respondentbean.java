package com.capgemini.surveyapp.bean;

public class Respondentbean {
	private String username;
	private String password;
	private String phoneNo;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Respondentbean [username=" + username + ", password=" + password + ", phoneNo=" + phoneNo + "]";
	}
	

}
