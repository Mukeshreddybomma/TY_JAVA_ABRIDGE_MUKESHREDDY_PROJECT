package com.capgemini.surveyapp.exception;

public class InvalidSurveynameException  extends RuntimeException{
	String message="survey is not distrubuted";
public InvalidSurveynameException() {
		
	}
	public InvalidSurveynameException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}



}
