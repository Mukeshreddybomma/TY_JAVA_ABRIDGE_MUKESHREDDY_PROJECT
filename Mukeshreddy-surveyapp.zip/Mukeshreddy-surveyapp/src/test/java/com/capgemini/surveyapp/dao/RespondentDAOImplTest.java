package com.capgemini.surveyapp.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.factory.Factory;

class RespondentDAOImplTest {

	@Test
	void testRespondentlogin() {
		RespondentDAO respondentDAO = Factory.getRespondentDAOInstance();
		assertEquals(true,respondentDAO.respondentlogin());
		
	}
	@Test
	void testRespondentlogin1() {
		RespondentDAO respondentDAO = Factory.getRespondentDAOInstance();
		assertEquals(false,respondentDAO.respondentlogin());
		
	}

	

}
