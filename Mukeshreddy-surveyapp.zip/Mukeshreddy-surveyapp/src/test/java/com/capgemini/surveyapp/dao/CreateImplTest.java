package com.capgemini.surveyapp.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.factory.Factory;

class CreateImplTest {

	@Test
	void testCreateSurvey() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		Surveyorbean surveyorbean = Factory.getSurveyorbeanInstance();
		assertEquals(true, surveyorDAO.createSurvey(surveyorbean));
}
	@Test
	
	void testCreateSurvey2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		Surveyorbean surveyor = Factory.getSurveyorbeanInstance();
		assertEquals(true, surveyorDAO.createSurvey(surveyor));
}
	}


