package com.capgemini.surveyapp.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.factory.Factory;

class ViewsurveyTest2 {

	@Test
	void testGetAllSurveys() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertNotNull(surveyorDAO.getAllSurveys());
	}
	@Test
	void testGetAllSurveys2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertNotNull(surveyorDAO.getAllSurveys());
	}
	}


