package com.capgemini.surveyapp.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.bean.Surveyorbean;
import com.capgemini.surveyapp.factory.Factory;

class SurveyorDAOImplTest {


	@Test
	@Tag("Login")
	void testSurveyorLogin(String username,String password) {
		Surveyorbean surveyorbean=Factory.getSurveyorbeanInstance();
		SurveyorDAO surveyorDAO=Factory.getSurveyorDAOInstance();
		surveyorbean.setUsername("mukeshreddy");
		surveyorbean.setPassword("Mukesh@13");
		assertEquals(true,surveyorDAO.validateSurveyor(username, password));
	}
	@Test
	@Tag("add")
	@BeforeEach
	@DisplayName("Create Survey")
	void testCreateSurvey1() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		Surveyorbean surveyorbean = Factory.getSurveyorbeanInstance();
		assertEquals(true, surveyorDAO.createSurvey(surveyorbean));
}
	@Test
	@Tag("add")
	@BeforeEach
	@DisplayName("Create Survey2")
	void testCreateSurvey2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		Surveyorbean surveyor = Factory.getSurveyorbeanInstance();
		assertEquals(true, surveyorDAO.createSurvey(surveyor));
}
	@Test
	@Tag("Edit")
	void testEditSurvey1() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		Surveyorbean surveyor = Factory.getSurveyorbeanInstance();
		assertEquals(true, surveyorDAO.editSurvey(surveyor));
	}
	@Test
	@Tag("Edit")
	void testEditSurvey2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		Surveyorbean surveyor = Factory.getSurveyorbeanInstance();
		assertEquals(true, surveyorDAO.editSurvey(surveyor));
	}
	@Test
	@Tag("Delete")
	void testDeleteSurvey1() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertEquals(true, surveyorDAO.deleteSurvey(null));
	}
	@Test
	@Tag("Delete")
	void testDeleteSurvey2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertEquals(true, surveyorDAO.deleteSurvey(null));
	}
	@Test
	@Tag("getall")
	void testGetAllSurveys1() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertNotNull(surveyorDAO.getAllSurveys());
	}
	@Test
	@Tag("getall")
	void testGetAllSurveys2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertNotNull(surveyorDAO.getAllSurveys());
	}
}

