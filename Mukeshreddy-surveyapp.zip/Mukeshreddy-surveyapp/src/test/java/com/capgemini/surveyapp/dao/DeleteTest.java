package com.capgemini.surveyapp.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveyapp.factory.Factory;

class DeleteTest {

	@Test
	void testDeleteSurvey() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertEquals(true, surveyorDAO.deleteSurvey(null));
	}
	@Test
	void testDeleteSurvey2() {
		SurveyorDAO surveyorDAO = Factory.getSurveyorDAOInstance();
		assertEquals(false, surveyorDAO.deleteSurvey(null));
	}
	}
